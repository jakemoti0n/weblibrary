from openai import OpenAI
from dotenv import load_dotenv
import os
import base64

# 환경변수 로드
load_dotenv()
api_key = os.getenv('OPENAI_API_KEY')
client = OpenAI(api_key=api_key)

def encode_image(image_path):
    """
    이미지 파일을 base64로 인코딩하는 함수
    🖼️ → 📝 변환!
    """
    try:
        with open(image_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
            return encoded_string
    except FileNotFoundError:
        print(f"❌ 파일을 찾을 수 없습니다: {image_path}")
        return None
    except Exception as e:
        print(f"❌ 이미지 인코딩 중 오류 발생: {e}")
        return None

def create_story_ending(base64_img1, base64_img2, original_story=""):
    """
    두 이미지를 보고 동화책 결말을 만드는 함수
    🎨 이미지 → 📖 스토리로 변환!
    """
    
    # 동화책 스타일로 스토리를 만들어달라고 요청
    story_prompt = f"""
    당신은 창의적인 동화 작가입니다. 
    
    다음 두 이미지를 보고 아름다운 동화의 결말 부분을 써주세요.
    
    요구사항:
    1. 아이들이 좋아할 만한 따뜻하고 행복한 이야기
    2. 두 이미지가 자연스럽게 연결되는 스토리
    3. 3-4개 문단으로 구성
    4. 교훈이나 의미가 담긴 마무리
    
    기존 이야기가 있다면: {original_story}
    
    이미지들을 보고 어떤 모험이나 만남이 일어났는지 상상해서 써주세요!
    """
    
    messages = [
        {
            'role': 'user',
            'content': [
                {'type': 'text', 'text': story_prompt},
                {
                    'type': 'image_url',
                    'image_url': {'url': f"data:image/jpeg;base64,{base64_img1}"}
                },
                {
                    'type': 'image_url', 
                    'image_url': {'url': f"data:image/jpeg;base64,{base64_img2}"}
                }
            ]
        }
    ]
    
    try:
        print("🎭 동화 작가 AI가 스토리를 만들고 있어요...")
        response = client.chat.completions.create(
            model='gpt-4o',
            messages=messages,
            max_tokens=800,  # 충분한 길이의 스토리를 위해
            temperature=0.8  # 창의성을 높이기 위해
        )
        
        story = response.choices[0].message.content
        print("✅ 스토리 완성!")
        return story
        
    except Exception as e:
        return f"스토리 생성 중 오류: {e}"

def main():
    """
    메인 실행 함수 - 여기서 실제 테스트!
    """
    # 이미지 경로들
    image_path1 = './data/images/local_stitch_terrarosa.jpg'
    image_path2 = './data/images/seolleung_terrarosa.jpg'
    
    # 이미지 인코딩
    print("🔄 이미지들을 로딩하는 중...")
    base64_image1 = encode_image(image_path1)
    base64_image2 = encode_image(image_path2)
    
    # 인코딩 실패 체크
    if not base64_image1 or not base64_image2:
        print("❌ 이미지 로딩에 실패했습니다. 파일 경로를 확인해주세요!")
        return
    
    print("✅ 이미지 로딩 완료!")
    
    # 🎬 실제 테스트 해보기!
    print("="*60)
    print("🏰 동화책 결말 생성기 테스트")
    print("="*60)
    
    # 기존 동화 설정 (선택사항)
    original_story = """
    옛날 옛적, 작은 마을에 살던 소녀 미나는 매일 같은 일상이 지루했습니다. 
    어느 날, 미나는 특별한 모험을 찾아 마을을 떠나기로 결심했습니다...
    """
    
    # 스토리 생성!
    new_story = create_story_ending(base64_image1, base64_image2, original_story)
    
    print("\n📖 생성된 동화 결말:")
    print("-" * 40)
    print(new_story)
    print("-" * 40)
    
    # 결과를 파일로 저장할 수도 있어요!
    try:
        with open("generated_story.txt", "w", encoding="utf-8") as f:
            f.write("🏰 생성된 동화 결말\n")
            f.write("="*40 + "\n")
            f.write(f"기존 스토리: {original_story}\n\n")
            f.write(f"생성된 결말:\n{new_story}\n")
        print("💾 스토리가 'generated_story.txt' 파일로 저장되었습니다!")
    except Exception as e:
        print(f"파일 저장 중 오류: {e}")

# 🚀 다른 파일에서 import해서 쓸 수도 있는 함수
def generate_fairy_tale(image1_path, image2_path, existing_story=""):
    """
    외부에서 호출할 수 있는 깔끔한 함수
    
    Args:
        image1_path: 첫 번째 이미지 경로
        image2_path: 두 번째 이미지 경로  
        existing_story: 기존 동화 내용 (선택사항)
    
    Returns:
        생성된 동화 결말 텍스트
    """
    base64_img1 = encode_image(image1_path)
    base64_img2 = encode_image(image2_path)
    
    if not base64_img1 or not base64_img2:
        return "이미지 로딩에 실패했습니다."
    
    return create_story_ending(base64_img1, base64_img2, existing_story)

# 스크립트로 직접 실행할 때만 main() 함수 호출
if __name__ == "__main__":
    main()